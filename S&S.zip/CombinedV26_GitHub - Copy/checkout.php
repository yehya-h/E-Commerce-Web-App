<?php
include_once ("connection.php");
// $_COOKIE['token'] = "cb4ae3c3d334f874edcdc7c2046cd3e392bbb374826c0fe7fd1bdadfa11bc184";
// if (!isset($_COOKIE['token']))
//     header("Location: check_login.php");
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout | S&S</title>
    <!-- <link rel="stylesheet" href="style.css" />
    <script type="text/javascript" src="proj.js"></script> -->
    <!-- <link rel="icon" type="image/x-icon" href="" /> -->
</head>
<body>
    
</body>
</html>