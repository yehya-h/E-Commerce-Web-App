<?php

class StripeClient{

    public $checkout;

   // public function
}


?>