<?php

//define("CST",22);
//not same for all (this is Project V0.6 version)
//OWNER CREDENTIALS
define("OWNER_EMAIL","ownerSAndS@gmail.com");
define("OWNER_PASSWORD","database");
define( "DB_SERVER" , "YOUR DB_HOST" );
define("DB_USERNAME","YOUR DB_USERNAME");
define("DB_PASSWORD","YOUR DB_PASSWd");
//PUT YOUR DB NAME
define("DB_NAME","projectv4");

//put YOUR HOST ADDRESS
 define("HOST_ADDRESS","192.168.1.10:3000");


//YOU CAN USE 1 DB ONLy JUST MODIFY IT IN api/androidConnection.php
define("DB_USERNAME_ANDROID","YOUR DB2 PASSWD");
define("DB_PASSWORD_ANDROID","YOUR DB2 PASSWD");
define("DB_NAMEV2","DB2 NAME");//you can comment it and modify it in api/androidConnection and set it to the 1st DB
define("OWNER_NAME","OWNER NAME");

define("COMPANY_MAIL","YOUR EMAIL");
define("MAIL_APP_PASSWORD","YOUR EMAIL APP PASSWORD");
define("STRIPE_SECRET_KEY","");
define("STRIPE_TAX_RATE_ID","");
?>